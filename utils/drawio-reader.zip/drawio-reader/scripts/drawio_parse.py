#!/usr/bin/env python3
"""Parse draw.io (.drawio / .xml / .drawio.svg) files into a readable summary.

Usage:
    python drawio_parse.py "file.drawio"                # markdown summary (all pages)
    python drawio_parse.py "file.drawio" --page 2       # one page (1-based index or name)
    python drawio_parse.py "file.drawio" --json         # structured JSON
    python drawio_parse.py "file.drawio" --xml          # dump decompressed XML (pretty)
    python drawio_parse.py "file.drawio" --styles       # include raw style strings
    python drawio_parse.py "file.drawio" --mermaid      # graph as Mermaid flowchart

Standard library only. Handles: plain and compressed <diagram>, bare <mxGraphModel>,
<object>/<UserObject> wrappers, multi-page, layers, containers, edge labels,
and .drawio.svg (content="" attribute).
"""
import argparse
import base64
import html
import json
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zlib

WRAPPERS = ("object", "UserObject")


# ----------------------------------------------------------------- loading
def read_text(path):
    with open(path, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeError:
            continue
    return raw.decode("utf-8", "replace")


def find_mxfile_text(text):
    """Return XML text containing <mxfile>/<mxGraphModel>; unwrap .drawio.svg."""
    stripped = text.lstrip()
    if stripped.startswith("<svg") or "<svg" in stripped[:500]:
        m = re.search(r'\bcontent="([^"]*)"', text)
        if not m:
            raise ValueError("SVG without draw.io 'content' attribute")
        return html.unescape(m.group(1))
    return text


def inflate_diagram(data):
    """base64 -> raw DEFLATE -> URL-decoded XML."""
    raw = base64.b64decode(data.strip())
    try:
        xml = zlib.decompress(raw, -15)
    except zlib.error:
        xml = zlib.decompress(raw)  # tolerate zlib-wrapped variants
    return urllib.parse.unquote(xml.decode("utf-8"))


def load_pages(path):
    """Return list of (page_name, page_id, mxGraphModel Element)."""
    text = find_mxfile_text(read_text(path))
    root = ET.fromstring(text)
    pages = []
    if root.tag == "mxGraphModel":
        return [("Page-1", None, root)]
    if root.tag != "mxfile":
        raise ValueError(f"Unexpected root element <{root.tag}>")
    for i, d in enumerate(root.findall("diagram"), 1):
        name = d.get("name") or f"Page-{i}"
        model = d.find("mxGraphModel")
        if model is None:
            payload = (d.text or "").strip()
            if not payload:
                continue
            if payload.startswith("<"):
                model = ET.fromstring(payload)
            else:
                model = ET.fromstring(inflate_diagram(payload))
        pages.append((name, d.get("id"), model))
    return pages


# ----------------------------------------------------------------- helpers
def parse_style(style):
    """'a=1;b=2;rounded' -> ({'a':'1','b':'2'}, ['rounded'])  (bare tokens = style names/shape keywords)"""
    kv, bare = {}, []
    for part in (style or "").split(";"):
        part = part.strip()
        if not part:
            continue
        if "=" in part:
            k, v = part.split("=", 1)
            kv[k] = v
        else:
            bare.append(part)
    return kv, bare


def html_to_text(value):
    """Strip HTML from a label, keeping line breaks."""
    if not value:
        return ""
    v = value
    v = re.sub(r"(?i)<\s*br\s*/?\s*>", "\n", v)
    v = re.sub(r"(?i)</\s*(div|p|li|tr|h[1-6])\s*>", "\n", v)
    v = re.sub(r"(?i)<\s*li[^>]*>", "- ", v)
    v = re.sub(r"(?i)</\s*t[dh]\s*>", " | ", v)
    v = re.sub(r"<[^>]+>", "", v)
    v = html.unescape(v).replace("\xa0", " ")
    v = re.sub(r"[ \t]+\n", "\n", v)
    v = re.sub(r"\n{3,}", "\n\n", v)
    return v.strip()


def fnum(x, default=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def shape_kind(kv, bare, is_edge, is_vertex):
    if is_edge:
        return "edge"
    if kv.get("shape"):
        return kv["shape"]
    for key in ("swimlane", "ellipse", "rhombus", "triangle", "cylinder", "hexagon", "cloud",
                "text", "image", "line", "label", "group", "actor", "umlActor", "note",
                "document", "process", "parallelogram", "trapezoid", "step", "table"):
        if key in bare or key in kv:
            return key
    if kv.get("rounded") == "1":
        return "roundRect"
    if "image" in kv:
        return "image"
    return "rect"


# ----------------------------------------------------------------- model
def build_page(name, page_id, model):
    root = model.find("root")
    cells = {}
    order = []
    for el in root:
        attrs = {}
        cell = el
        if el.tag in WRAPPERS:
            attrs = dict(el.attrib)
            cell = el.find("mxCell")
            if cell is None:
                continue
        elif el.tag != "mxCell":
            continue
        cid = attrs.get("id") or cell.get("id")
        if cid is None:
            continue
        style = cell.get("style", "")
        kv, bare = parse_style(style)
        is_edge = cell.get("edge") == "1"
        is_vertex = cell.get("vertex") == "1"
        raw_label = attrs.get("label", cell.get("value", "")) if attrs else cell.get("value", "")
        geom = cell.find("mxGeometry")
        g = None
        pts = []
        src_pt = tgt_pt = None
        if geom is not None:
            g = {
                "x": fnum(geom.get("x")), "y": fnum(geom.get("y")),
                "w": fnum(geom.get("width")), "h": fnum(geom.get("height")),
                "relative": geom.get("relative") == "1",
            }
            arr = geom.find("Array[@as='points']")
            if arr is not None:
                pts = [(fnum(p.get("x")), fnum(p.get("y"))) for p in arr.findall("mxPoint")]
            for p in geom.findall("mxPoint"):
                pt = (fnum(p.get("x")), fnum(p.get("y")))
                if p.get("as") == "sourcePoint":
                    src_pt = pt
                elif p.get("as") == "targetPoint":
                    tgt_pt = pt
        extra = {k: v for k, v in attrs.items() if k not in ("id", "label", "placeholders", "tags")}
        rec = {
            "id": cid,
            "parent": cell.get("parent"),
            "kind": None,
            "vertex": is_vertex,
            "edge": is_edge,
            "label": html_to_text(raw_label),
            "raw_label": raw_label,
            "style": style,
            "style_kv": kv,
            "source": cell.get("source"),
            "target": cell.get("target"),
            "geometry": g,
            "waypoints": pts,
            "source_point": src_pt,
            "target_point": tgt_pt,
            "collapsed": cell.get("collapsed") == "1",
            "hidden": cell.get("visible") == "0",
            "tags": attrs.get("tags", "").split() if attrs.get("tags") else [],
            "properties": extra,
            "placeholders": attrs.get("placeholders") == "1",
            "wrapped": el.tag in WRAPPERS,
        }
        rec["kind"] = shape_kind(kv, bare, is_edge, is_vertex)
        rec["_bare"] = bare
        cells[cid] = rec
        order.append(cid)

    # resolve placeholders (%prop%) using the cell's own properties
    for c in cells.values():
        if c["placeholders"] and "%" in c["label"]:
            c["label"] = re.sub(r"%(\w+)%", lambda m: c["properties"].get(m.group(1), m.group(0)), c["label"])

    # layers: children of root cell "0" (or whose parent is the root cell)
    root_id = next((i for i in order if cells[i]["parent"] is None), "0")
    layers = [i for i in order if cells[i]["parent"] == root_id]

    def is_layer(c):
        return c["parent"] == root_id

    # absolute positions (children of containers use parent-relative coords)
    def abs_pos(c, seen=None):
        g = c["geometry"]
        if not g or g["relative"] and c["edge"]:
            return None
        x, y = g["x"], g["y"]
        p = cells.get(c["parent"])
        seen = seen or set()
        while p is not None and not is_layer(p) and p["id"] not in seen and p["parent"] is not None:
            seen.add(p["id"])
            pg = p["geometry"]
            if pg:
                x += pg["x"]
                y += pg["y"]
            p = cells.get(p["parent"])
        return x, y

    for c in cells.values():
        c["abs"] = abs_pos(c) if not is_layer(c) and c["id"] != root_id else None
        if c["abs"] and c["geometry"]:
            c["abs_box"] = [c["abs"][0], c["abs"][1], c["geometry"]["w"], c["geometry"]["h"]]
        else:
            c["abs_box"] = None

    return {
        "name": name, "id": page_id,
        "model_attrs": dict(model.attrib),
        "root_id": root_id, "layers": layers, "order": order, "cells": cells,
    }


_SHORT = {}  # id -> short id (common prefix removed), filled per page by prepare_names()
_DUP = set()  # labels that appear on more than one cell


def prepare_names(page):
    """Compute short ids and the set of duplicated labels so names stay unambiguous."""
    import os
    cells = page["cells"]
    pre = os.path.commonprefix([i for i, c in cells.items() if c["vertex"] or c["edge"]])
    pre = pre[: pre.rfind("-") + 1] if "-" in pre else ""
    _SHORT.clear()
    _DUP.clear()
    counts = {}
    for cid, c in cells.items():
        _SHORT[cid] = cid[len(pre):] or cid
        if c["label"] and not c["edge"]:
            counts[c["label"]] = counts.get(c["label"], 0) + 1
    _DUP.update(l for l, n in counts.items() if n > 1)


def display_name(c):
    sid = _SHORT.get(c["id"], c["id"])
    if c["label"]:
        first = c["label"].replace("\n", " / ")
        first = first if len(first) <= 80 else first[:77] + "..."
        return f"{first}#{sid}" if c["label"] in _DUP else first
    return f"<{c['kind']} #{sid}>"


# ----------------------------------------------------------------- output
def render_structure(page):
    """Connected components; nested tree (children ordered left->right) when the component is a tree/forest."""
    cells = page["cells"]
    out_e, in_e = {}, {}
    nodes = set()
    for e in cells.values():
        if e["edge"] and e["source"] in cells and e["target"] in cells:
            out_e.setdefault(e["source"], []).append(e["target"])
            in_e.setdefault(e["target"], []).append(e["source"])
            nodes.update((e["source"], e["target"]))
    if not nodes:
        return ""

    def cx(i):
        b = cells[i]["abs_box"]
        return (b[0] + b[2] / 2) if b else 0

    # components via undirected traversal
    adj = {n: set(out_e.get(n, [])) | set(in_e.get(n, [])) for n in nodes}
    seen, comps = set(), []
    for n in sorted(nodes, key=lambda i: (cells[i]["abs_box"] or [0, 0])[:2][::-1]):
        if n in seen:
            continue
        comp, stack = [], [n]
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            comp.append(x)
            stack.extend(adj[x] - seen)
        comps.append(comp)

    lines = ["### Graph structure", f"{len(comps)} connected component(s).", ""]
    for k, comp in enumerate(comps, 1):
        cs = set(comp)
        edges_n = sum(len([t for t in out_e.get(n, []) if t in cs]) for n in comp)
        is_tree = all(len(in_e.get(n, [])) <= 1 for n in comp) and edges_n == len(comp) - 1
        roots = [n for n in comp if not in_e.get(n)]
        if is_tree and len(roots) == 1:
            lines.append(f"Component {k}: tree, {len(comp)} nodes (children ordered by x, left to right)")
            def rec(n, d):
                lines.append("  " * d + "- " + display_name(cells[n]))
                for t in sorted(out_e.get(n, []), key=cx):
                    rec(t, d + 1)
            rec(roots[0], 0)
        else:
            lines.append(f"Component {k}: general graph, {len(comp)} nodes, {edges_n} edges (see Connections)")
        lines.append("")
    return "\n".join(lines)


def render_markdown(page, show_styles=False):
    prepare_names(page)
    cells, order, root_id = page["cells"], page["order"], page["root_id"]
    out = []
    ma = page["model_attrs"]
    out.append(f"## Page: {page['name']}")
    size = ""
    if ma.get("pageWidth"):
        size = f" | page {ma.get('pageWidth')}x{ma.get('pageHeight')}"
    out.append(f"_model dx={ma.get('dx')} dy={ma.get('dy')}{size}_\n")

    vertices = [c for c in cells.values() if c["vertex"]]
    edges = [c for c in cells.values() if c["edge"]]
    out.append(f"Cells: {len(vertices)} vertices, {len(edges)} edges, {len(page['layers'])} layer(s)\n")

    children = {}
    for i in order:
        children.setdefault(cells[i]["parent"], []).append(i)

    def fmt_vertex(c, depth):
        b = c["abs_box"]
        pos = f" @({b[0]:.0f},{b[1]:.0f}) {b[2]:.0f}x{b[3]:.0f}" if b else ""
        extras = []
        kv = c["style_kv"]
        if kv.get("fillColor") and kv["fillColor"] != "none":
            extras.append(f"fill={kv['fillColor']}")
        if c["tags"]:
            extras.append("tags=" + ",".join(c["tags"]))
        if c["hidden"]:
            extras.append("hidden")
        if c["collapsed"]:
            extras.append("collapsed")
        if c["properties"]:
            extras.append("props=" + json.dumps(c["properties"], ensure_ascii=False))
        ex = f" [{'; '.join(extras)}]" if extras else ""
        label = c["label"].replace("\n", " / ") if c["label"] else "(no label)"
        line = f"{'  ' * depth}- **{label}** `{_SHORT.get(c['id'], c['id'])}` ({c['kind']}){pos}{ex}"
        if show_styles:
            line += f"\n{'  ' * depth}  style: `{c['style']}`"
        return line

    def walk(pid, depth):
        for i in children.get(pid, []):
            c = cells[i]
            if c["edge"]:
                continue
            if c["vertex"]:
                # edge labels are vertices parented to an edge; skip here, shown on the edge
                if c["parent"] in cells and cells[c["parent"]]["edge"]:
                    continue
                out.append(fmt_vertex(c, depth))
                walk(i, depth + 1)

    out.append("### Shapes (nesting = containment)")
    for lid in page["layers"]:
        layer = cells[lid]
        name = layer["label"] or ("Background Layer" if lid == page["layers"][0] else lid)
        flag = " (hidden)" if layer["hidden"] else ""
        out.append(f"**Layer `{lid}`: {name}**{flag}")
        walk(lid, 0)
    out.append("")

    out.append("### Connections")
    if not edges:
        out.append("(none)")
    for e in edges:
        s = cells.get(e["source"]) if e["source"] else None
        t = cells.get(e["target"]) if e["target"] else None
        sname = display_name(s) if s else (f"(free point {e['source_point'][0]:.0f},{e['source_point'][1]:.0f})" if e["source_point"] else "(unattached)")
        tname = display_name(t) if t else (f"(free point {e['target_point'][0]:.0f},{e['target_point'][1]:.0f})" if e["target_point"] else "(unattached)")
        kv = e["style_kv"]
        se, ee = kv.get("startArrow", "none"), kv.get("endArrow", "classic")
        if se != "none" and ee != "none":
            arrow = "<->"
        elif ee == "none" and se == "none":
            arrow = "---"
        elif se != "none":
            arrow = "<-"
        else:
            arrow = "->"
        labels = [e["label"]] if e["label"] else []
        labels += [cells[i]["label"] for i in children.get(e["id"], []) if cells[i]["vertex"] and cells[i]["label"]]
        lab = f" [{' | '.join(l.replace(chr(10), ' ') for l in labels)}]" if labels else ""
        notes = []
        if kv.get("dashed") == "1":
            notes.append("dashed")
        if se not in ("none",) or ee not in ("classic",):
            notes.append(f"arrows: start={se}, end={ee}")
        if e["waypoints"]:
            notes.append(f"{len(e['waypoints'])} waypoint(s)")
        nt = f" ({', '.join(notes)})" if notes else ""
        out.append(f"- {sname} {arrow} {tname}{lab}{nt} `{_SHORT.get(e['id'], e['id'])}`")
        if show_styles:
            out.append(f"  style: `{e['style']}`")
    out.append("")
    struct = render_structure(page)
    if struct:
        out.append(struct)
    return "\n".join(out)


def render_mermaid(page):
    cells = page["cells"]
    lines = ["flowchart TD"]
    ids = {}

    def mid(cid):
        return ids.setdefault(cid, f"n{len(ids)}")

    def esc(t):
        return (t or "").replace('"', "'").replace("\n", "<br/>")

    for c in cells.values():
        if c["vertex"] and c["label"] and not (c["parent"] in cells and cells[c["parent"]]["edge"]):
            lines.append(f'    {mid(c["id"])}["{esc(c["label"])}"]')
    for e in cells.values():
        if e["edge"] and e["source"] in cells and e["target"] in cells:
            lab = f'|"{esc(e["label"])}"|' if e["label"] else ""
            lines.append(f"    {mid(e['source'])} -->{lab} {mid(e['target'])}")
    return "\n".join(lines)


def to_json(page):
    cells = {}
    for cid, c in page["cells"].items():
        d = {k: v for k, v in c.items() if k not in ("raw_label", "style_kv", "_bare", "abs")}
        d["style_kv"] = c["style_kv"]
        cells[cid] = d
    return {"name": page["name"], "id": page["id"], "model_attrs": page["model_attrs"],
            "layers": page["layers"], "cells": cells}


# ----------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path")
    ap.add_argument("--page", help="page index (1-based) or exact name")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--xml", action="store_true", help="print decompressed XML of the selected pages")
    ap.add_argument("--styles", action="store_true", help="show raw style strings")
    ap.add_argument("--mermaid", action="store_true")
    a = ap.parse_args()

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    pages = load_pages(a.path)
    if a.page:
        sel = [p for i, p in enumerate(pages, 1) if a.page == str(i) or a.page == p[0]]
        if not sel:
            sys.exit(f"Page '{a.page}' not found. Pages: " + ", ".join(f"{i}:{p[0]}" for i, p in enumerate(pages, 1)))
        pages = sel

    if a.xml:
        for name, _, model in pages:
            print(f"<!-- page: {name} -->")
            ET.indent(model)
            print(ET.tostring(model, encoding="unicode"))
        return

    built = [build_page(*p) for p in pages]
    if a.json:
        print(json.dumps([to_json(b) for b in built], ensure_ascii=False, indent=2))
    elif a.mermaid:
        for b in built:
            print(f"%% page: {b['name']}")
            print(render_mermaid(b))
    else:
        print(f"# {a.path}\nPages: " + ", ".join(f"{i}:{p[0]}" for i, p in enumerate(pages, 1)) + "\n")
        for b in built:
            print(render_markdown(b, a.styles))


if __name__ == "__main__":
    main()
