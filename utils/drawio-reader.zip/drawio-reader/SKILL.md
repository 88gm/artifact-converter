---
name: drawio-reader
description: Ler e interpretar arquivos de diagrama draw.io / diagrams.net (.drawio, .drawio.svg, .xml com mxfile/mxGraphModel). Use sempre que o usuário mencionar um arquivo .drawio, pedir para entender, resumir, extrair fluxo/componentes/conexões de um diagrama ou converter para Mermaid/texto.
---

# Leitura de arquivos draw.io

Um `.drawio` é XML. **Não leia o arquivo cru quando ele for grande ou comprimido**: use o script, que decodifica e resolve a estrutura (hierarquia, rótulos, conexões).

## Fluxo padrão

1. Rode o parser (só biblioteca padrão do Python; caminhos sempre entre aspas duplas):

```
python "<skill-dir>/scripts/drawio_parse.py" "caminho/arquivo.drawio"
```

Opções: `--page N|nome`, `--json` (estrutura completa), `--mermaid` (fluxograma), `--styles` (mostra a string de estilo crua), `--xml` (XML descomprimido e indentado).

2. Interprete a saída: seções **Shapes** (aninhamento = contenção, com posição absoluta `@(x,y) wxh`), **Connections** (`origem -> destino [rótulo]`) e **Graph structure** (componentes conectados; quando o componente é uma árvore, é impresso aninhado com filhos ordenados por x, da esquerda para a direita). Rótulos repetidos aparecem como `rótulo#idcurto` (ex.: `A#7`) para distinguir os nós. Em árvores de derivação/organogramas, ler as folhas da esquerda para a direita dá a sequência final.
3. Responda em termos do domínio do diagrama (fluxo, arquitetura, entidades), não em termos de XML, a menos que peçam.
4. Se o arquivo tiver várias páginas, liste-as e diga qual analisou.

Se Python não estiver disponível, veja `references/format.md` (seção "Decodificar manualmente").

## Modelo mental (essencial)

```
mxfile > diagram(name,id) [1 por página] > mxGraphModel > root > mxCell*
```

- `<diagram>` contém `<mxGraphModel>` direto **ou** texto comprimido (base64 → deflate raw → URL-decode). O script trata ambos.
- `id="0"` é a raiz; células com `parent="0"` são **camadas** (normalmente `id="1"`). Nunca são shapes.
- `vertex="1"` = forma; `edge="1"` = conector com `source`/`target` (ids). Sem source/target, a ponta é livre (`sourcePoint`/`targetPoint` na geometria).
- `parent` = contenção. **Filhos de contêiner usam coordenadas relativas ao pai**; o script converte para absolutas.
- `value` = rótulo (frequentemente HTML: `&lt;b&gt;`, `&lt;br&gt;`). Vértice cujo `parent` é uma aresta = **rótulo da aresta**.
- Metadados: `<object>`/`<UserObject>` envolve o `mxCell`; o `id` e os atributos custom ficam no wrapper; o texto está em `label`, e `%prop%` é substituído quando `placeholders="1"`. `tags`, `link`, `tooltip` também ficam aí.
- `style` = `chave=valor;chave=valor;palavra` (tokens sem `=` são nomes de estilo/forma, ex.: `ellipse`, `swimlane`, `text`). Tabela em `references/styles.md`.

## Como inferir semântica

- **Forma → significado**: `rhombus` = decisão; `ellipse`/`rounded` com `arcSize` alto = início/fim (terminator); `shape=cylinder3` = banco de dados; `swimlane`/`container=1` = agrupamento/raia; `shape=mxgraph.aws4.*` etc. = ícone de provedor (o sufixo diz o serviço); `text` sem borda = anotação.
- **Direção da aresta**: `endArrow` (padrão `classic`) é a ponta em `target`; `startArrow` a ponta em `source`. `endArrow=none;startArrow=none` = ligação sem direção.
- **Cores/tracejado**: `fillColor`, `strokeColor`, `dashed=1` costumam carregar significado (ex.: tracejado = opcional/assíncrono; cor = camada/ambiente). Mencione quando parecer intencional, não invente legenda.
- **Sem conexão explícita ≠ sem relação**: setas desenhadas soltas (sem source/target) ou proximidade/contenção podem indicar relação. Verifique `Connections` com "free point" e use as coordenadas.
- **Ordem visual**: draw.io não guarda ordem de fluxo; deduza-a do grafo (e do layout: x/y) e diga quando for inferência.
- Células `hidden`/camadas ocultas (`visible="0"`) podem ser lixo ou conteúdo alternativo; sinalize.

## Limitações

- `.drawio.png` guarda o XML em chunk `zTXt/tEXt` (chave `mxfile`), não suportado pelo script (ver `references/format.md`).
- Ícones/imagens (`image=data:...`) são só referenciados; o conteúdo visual não é interpretado.
- O script não renderiza; para ver o desenho: `drawio -x -f png` (CLI do draw.io Desktop), se instalado.

## Referências (carregue sob demanda)

- `references/format.md` — estrutura XML completa, atributos de `mxfile`/`mxGraphModel`/`mxCell`/`mxGeometry`, compressão, camadas, tabelas, armadilhas.
- `references/styles.md` — dicionário das chaves de estilo (vértices, arestas, setas, contêineres, texto).
- `examples/` — `sample.drawio` (multi-página, swimlane, object+placeholders) e `sample-compressed.drawio`.
