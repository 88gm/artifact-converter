# Formato de arquivo draw.io (.drawio)

## Hierarquia

```xml
<mxfile host="app.diagrams.net" modified="..." agent="..." etag="..." version="24.x" type="device" compressed="false">
  <diagram id="abc" name="Página-1">
    <mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1"
                  connect="1" arrows="1" fold="1" page="1" pageScale="1"
                  pageWidth="827" pageHeight="1169" math="0" shadow="0">
      <root>
        <mxCell id="0"/>                       <!-- raiz -->
        <mxCell id="1" parent="0"/>            <!-- camada padrão -->
        <mxCell id="2" value="A" style="rounded=1;" vertex="1" parent="1">
          <mxGeometry x="40" y="40" width="120" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="3" style="edgeStyle=orthogonalEdgeStyle;" edge="1" parent="1" source="2" target="4">
          <mxGeometry relative="1" as="geometry"/>
        </mxCell>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>
```

Também é válido um arquivo cujo elemento raiz é diretamente `<mxGraphModel>` (sem `mxfile`).

### Atributos
- **mxfile**: `host`, `modified`, `agent`, `etag`, `version`, `type` (device/google/…), `compressed` (opcional; hoje o padrão do app é XML puro).
- **diagram**: `id`, `name` (nome da aba/página). Uma `<diagram>` por página.
- **mxGraphModel**: `dx/dy` (scroll do editor), `grid`, `gridSize`, `guides`, `tooltips`, `connect`, `arrows`, `fold`, `page`, `pageScale`, `pageWidth`, `pageHeight`, `background`, `math`, `shadow`. Só afetam editor/impressão, não a semântica.
- **mxCell**: `id` (único na página), `value` (rótulo), `style`, `parent`, `vertex="1"`/`edge="1"`, `source`, `target`, `connectable="0"`, `collapsed="1"`, `visible="0"`.
- **mxGeometry** (`as="geometry"`): `x`, `y`, `width`, `height`, `relative="1"`.
  - Vértices: `x,y` = canto superior esquerdo, **relativo ao pai** (absoluto se o pai é camada).
  - Arestas: `relative="1"`; filhos: `<Array as="points"><mxPoint x y/></Array>` (waypoints, absolutos ao pai), `<mxPoint as="sourcePoint"/>` / `as="targetPoint"` (pontas livres), `<mxPoint as="offset"/>`.
  - Rótulo de aresta (vértice filho da aresta): `x` ∈ [-1,1] = posição ao longo da aresta (-1 origem, 1 destino), `y` = deslocamento perpendicular em px.
  - Contêiner colapsável: `<mxRectangle as="alternateBounds"/>`.

## Compressão

Se `<diagram>` tem texto em vez de `<mxGraphModel>`:

`XML → encodeURIComponent → deflate RAW (sem cabeçalho zlib) → base64`.

### Decodificar manualmente

Python:
```python
import base64, zlib, urllib.parse
xml = urllib.parse.unquote(zlib.decompress(base64.b64decode(txt), -15).decode())
```
Node:
```js
const zlib=require('zlib');
const xml=decodeURIComponent(zlib.inflateRawSync(Buffer.from(txt,'base64')).toString());
```
Online: https://jgraph.github.io/drawio-tools/tools/convert.html. No app: *Extras > Edit Diagram*; para salvar sem compressão: *File > Properties > Compressed* (desmarcar).

Recomprimir: inverso (quote → deflate raw `-15` → base64). Não é necessário: XML puro é aceito.

## Outros contêineres do mesmo XML

- **.drawio.svg / .drawio.html**: SVG com atributo `content="&lt;mxfile ..."` (XML escapado). O script trata.
- **.drawio.png**: XML no chunk PNG `tEXt`/`zTXt` com chave `mxfile` (URL-encoded, possivelmente deflate).
- **Bibliotecas** (`<mxlibrary>[...]</mxlibrary>`): JSON com `xml` comprimido por item.
- **Exportação de página inteira** também pode vir como `<mxGraphModel>` puro (Extras > Edit Diagram).

## Camadas, grupos, contêineres

- Camada: `<mxCell id="L" value="Nome" parent="0"/>`; `visible="0"` esconde; `locked` via style em algumas versões. Filhos apontam `parent="L"`.
- Grupo: célula com `style="group"` (sem borda) e filhos com `parent=<grupo>`.
- Contêiner: `swimlane`, `container=1`, `shape=table` etc. Filhos com coords relativas.
- Aresta pertence ao ancestral comum mais interno das pontas; arestas entre contêineres costumam ter `parent="1"`.
- **Tabelas** (`shape=table` > `shape=tableRow` > células `vertex`): linhas/colunas via hierarquia; texto em cada célula. Comum em ER/UML (`swimlane` com `childLayout=stackLayout`: campos empilhados, cada campo é um vértice filho).
- **Tags**: `tags="a b"` no wrapper. **Links**: `link="https://..."` ou `link="data:page/id,<diagram id>"` (navega a outra página).

## Metadados (`object`/`UserObject`)

```xml
<object label="&lt;b&gt;%nome%&lt;/b&gt;" placeholders="1" nome="Auth" owner="X" tooltip="..." link="..." id="5">
  <mxCell style="..." vertex="1" parent="1"><mxGeometry .../></mxCell>
</object>
```
O `id` **fica no wrapper**, não no mxCell. Atributos extras = propriedades de dados (Edit Data). `%date{...}%`, `%page%`, `%pagenumber%`, `%id%` são placeholders internos.

## Diagramas de outros tipos que aparecem via estilo

Sequência UML (`umlLifeline`, mensagens = arestas com `y` = ordem temporal), BPMN (`mxgraph.bpmn.*`), AWS/Azure/GCP (`mxgraph.aws4.*`), ER (`edgeStyle=entityRelationEdgeStyle`, `endArrow=ERmany|ERone|ERmandOne|ERzeroToMany`), fluxogramas (`mxgraph.flowchart.*` ou formas básicas), org charts (árvore por arestas), mockups (`mxgraph.mockup.*`). Em sequência, a ordem é dada pela coordenada **y**.

## Armadilhas comuns

1. Confundir camada (`parent="0"`) com forma.
2. Esquecer que coords de filhos são relativas.
3. Ler `value` com HTML como texto literal (`&lt;br&gt;`): decodifique.
4. Rótulo de aresta pode estar em `value` da aresta **ou** em vértice filho.
5. Arestas com `source`/`target` inexistente (alvo removido) = ponta solta.
6. Ids duplicados entre páginas são normais; únicos só dentro da página.
7. `%prop%` sem `placeholders="1"` é literal.
8. Arquivos com `mxGraphModel` grande: use `--json`/filtros em vez de imprimir o XML.
9. Comentários XML/atributos desconhecidos em versões novas: ignore, não falhe.

## Fontes

- draw.io: Style reference (https://www.drawio.com/docs/reference/diagram-generation/style-reference/), XML reference do repositório jgraph/drawio-mcp, doc de `mxCell` do mxGraph, drawio-tools (convert.html), blog "Extracting the XML from mxfiles".
