# Dicionário de estilos draw.io

`style="k=v;k=v;token;"`. Tokens sem `=` são nomes de estilo predefinido/forma (`ellipse`, `rhombus`, `swimlane`, `text`, `group`, `line`, `triangle`, `image`...). Chaves ausentes usam padrão do tema.

## Forma
| Chave | Valores / significado |
|---|---|
| `shape` | tipo: `rectangle ellipse rhombus triangle hexagon cloud cylinder cylinder3 line arrow doubleEllipse actor label swimlane image cube note document folder card parallelogram trapezoid process step table tableRow datastore` … ou stencil `mxgraph.<lib>.<nome>` |
| `rounded`, `arcSize` | cantos arredondados; raio em % |
| `perimeter` | onde arestas encostam (`rectanglePerimeter`, `ellipsePerimeter`, `rhombusPerimeter`, `trianglePerimeter`, `hexagonPerimeter2`, `parallelogramPerimeter`…) |
| `direction` | `north south east west` (rotação 90°) |
| `flipH`, `flipV`, `rotation` | espelho / graus |
| `aspect=fixed`, `fixedSize` | proporção |

Stencils: `mxgraph.flowchart.*`, `bpmn.*`, `aws4.*`, `azure.*`, `gcp.*`, `cisco.*`, `kubernetes.*`, `uml.*`, `er.*`, `electrical.*`, `pid.*`, `mockup.*`, `eip.*`. O último segmento nomeia o ícone (ex.: `mxgraph.aws4.lambda`, `mxgraph.flowchart.decision`, `mxgraph.flowchart.terminator`).

Formas UML: `umlActor umlLifeline umlFrame umlBoundary umlEntity umlControl umlState lollipop component module providedRequiredInterface`.

## Preenchimento e traço
`fillColor` (#hex/`none`/`default`), `gradientColor`, `gradientDirection`, `strokeColor`, `strokeWidth`, `dashed=1`, `dashPattern`, `opacity`, `fillOpacity`, `strokeOpacity`, `shadow=1`, `glass=1`, `sketch=1` (estilo rabisco), `comic=1`, `fillStyle`.
Paleta padrão de tema: azul `#dae8fc/#6c8ebf`, verde `#d5e8d4/#82b366`, amarelo `#fff2cc/#d6b656`, laranja `#ffe6cc/#d79b00`, vermelho `#f8cecc/#b85450`, roxo `#e1d5e7/#9673a6`, cinza `#f5f5f5/#666666`.

## Texto
`html=1` (rótulo é HTML), `whiteSpace=wrap`, `fontSize`, `fontFamily`, `fontColor`, `fontStyle` (bitmask: 1 negrito, 2 itálico, 4 sublinhado; soma), `align`, `verticalAlign`, `labelPosition`/`verticalLabelPosition` (posiciona rótulo fora da forma), `spacing*`, `overflow`, `labelBackgroundColor`, `labelBorderColor`, `horizontal=0` (texto vertical), `textOpacity`.
`text;` (token) + `strokeColor=none;fillColor=none` = rótulo solto/anotação.

## Imagem
`image=<url|data:image/...>`, `imageWidth/Height`, `imageAlign`, `imageAspect`, `shape=image`.

## Contêiner / swimlane / layout
`swimlane`, `container=1`, `collapsible`, `startSize` (altura do cabeçalho), `horizontal=0` (raia vertical/cabeçalho à esquerda), `swimlaneFillColor`, `childLayout` (`stackLayout|treeLayout|flowLayout|rack`), `horizontalStack`, `resizeParent`, `resizeLast`, `marginBottom`, `recursiveResize`, `pointerEvents=0` (contêiner não captura conexões).

## Arestas
| Chave | Notas |
|---|---|
| `edgeStyle` | `orthogonalEdgeStyle`, `elbowEdgeStyle`, `entityRelationEdgeStyle`, `segmentEdgeStyle`, `loopEdgeStyle`, `isometricEdgeStyle`, vazio = reta |
| `curved`, `rounded`, `elbow` | curva / cantos / direção do cotovelo |
| `startArrow`, `endArrow` | `none classic classicThin block blockThin open openThin oval diamond diamondThin box halfCircle circle circlePlus cross baseDash doubleBlock dash async openAsync` e ER: `ERone ERmany ERmandOne ERoneToMany ERzeroToOne ERzeroToMany`. **Padrão: start=none, end=classic** |
| `startFill`, `endFill` | 0 = vazado (ex.: diamante vazado = agregação UML; `endFill=1` cheio = composição) |
| `startSize`, `endSize` | tamanho do marcador |
| `exitX/Y`, `entryX/Y` | ponto de saída/entrada normalizado 0–1 na forma; `exitDx/Dy`, `entryDx/Dy` = offset; `exitPerimeter`, `entryPerimeter` |
| `jumpStyle`, `jumpSize` | saltos em cruzamentos |
| `orthogonalLoop` | laço em si mesmo |
| `dashed=1`, `strokeColor`, `strokeWidth` | semântica visual (assíncrono, dependência…) |

Convenções UML por aresta: herança = `endArrow=block;endFill=0`; realização = `dashed=1;endArrow=block;endFill=0`; dependência = `dashed=1;endArrow=open`; agregação = `startArrow=diamondThin;startFill=0;endArrow=none`; composição = mesmo com `startFill=1`; associação = `endArrow=none` ou `open`.

## Comportamento
`movable resizable rotatable bendable editable deletable cloneable foldable connectable` (=0 bloqueia), `autosize`, `pointerEvents`, `noLabel=1`, `points=[[...]]` (pontos de conexão custom).
